package question_2_bridge_processing;

public class BridgeProcessingSimulationMain {
    public static void main(String[] args) throws Exception {
        final BridgeProcessingSimulation bridgeProcessingSimulation = new BridgeProcessingSimulation();
        bridgeProcessingSimulation.execute();
    }
}
